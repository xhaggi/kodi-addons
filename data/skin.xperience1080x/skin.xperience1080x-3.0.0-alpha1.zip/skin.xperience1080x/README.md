Xperience1080
=============

1080p mod of the Xperience skin for XBMC.

See http://forum.xbmc.org/showthread.php?tid=146690 for more infos.
